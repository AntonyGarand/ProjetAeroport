﻿// ListeDoublementChainee.cs 
// Description du programme : 
// Programé par Alexis Coté
// Le : 21 octobre 2014           
// Historique des modifications
// Par :
// Le :
// Modif :

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Structure.ListeDoublementChainee
{
    public class ListeDoublementChainee<T>
    {
        //Variables membres
        private int nombre;
        private Noeud<T> debut = null;


        private Noeud<T> fin = null;

        //Constructeur


        /// <summary>
        /// Initialise cette liste doublement chainee.
        /// </summary>
        public ListeDoublementChainee()
        {
            nombre = 0;
        }

        /// <summary>
        /// Cree une liste doublement chainee a partir d'une autre liste doublement chainee.
        /// </summary>
        /// <param name="data">Liste Chainee du meme type que cette liste. Sera ajoute a la chaine.</param>
        public ListeDoublementChainee(ListeDoublementChainee<T> data)
        {
            AjouterDebut(data);
        }





        //Methodes

        /// <summary>
        /// Ajout d'un noeud au debut de la chaine
        /// </summary>
        /// <param name="valeur">Valeur attribue au noeud</param>
        public void AjouterDebut(T valeur)
        {
                Noeud<T> noeud = new Noeud<T>(valeur);
                noeud.Suivant = debut;
                if (debut != null)
                    debut.Precedent = noeud;
                else
                    fin = noeud;

                debut = noeud;
                nombre++;
            
        }

        /// <summary>
        /// Ajoute une liste chaine au debut de cette liste.
        /// </summary>
        /// <param name="data">Liste Doublement chianee qui sera ajoutee.</param>
        public void AjouterDebut(ListeDoublementChainee<T> data)
        {
            if (!data.EstVide)
            {
                ListeDoublementChainee<T> nouvelleListe = CopierListe(data);
                if (debut != null)
                {

                    debut.Precedent = nouvelleListe.Fin;
                    nouvelleListe.Fin.Suivant = debut;
                    debut = nouvelleListe.Debut;
                }
                else
                {
                    debut = nouvelleListe.Debut;
                    fin = nouvelleListe.Fin;
                }
                nombre += nouvelleListe.nombre;
            }
            else
                throw new InvalidOperationException("La liste que vous tentez d'ajouter est vide.");
        }

        /// <summary>
        /// Ajout d'un noeud a la fin de la chaine
        /// </summary>
        /// <param name="valeur">Valeur attribue au noeud</param>
        public void AjouterFin(T valeur)
        {
            Noeud<T> noeud = new Noeud<T>(valeur);
            noeud.Precedent = fin;
            if (fin != null)
                fin.Suivant = noeud;
            else
                debut = noeud;
            fin = noeud;
            nombre++;
        }

        /// <summary>
        /// Permet d'ajouter une liste doublement chainee a la fin de cette liste.
        /// </summary>
        /// <param name="data">Liste qui sera ajoute</param>
        public void AjouterFin(ListeDoublementChainee<T> data)
        {
            if (!data.EstVide)
            {
                ListeDoublementChainee<T> nouvelleListe = CopierListe(data);
                if (debut != null)
                {
                    fin.Suivant = nouvelleListe.Debut;
                    nouvelleListe.debut.Precedent = fin;
                }
                else
                {
                    debut = nouvelleListe.Debut;
                }
                fin = nouvelleListe.Fin;
                nombre += nouvelleListe.Nombre;
            }
            else
                throw new InvalidOperationException("La liste que vous tentez d'ajouter est vide");
        }

        /// <summary>
        /// Permet d'ajouter un noeud a l'index choisi.
        /// </summary>
        /// <param name="index">Index qui precedera le nouveau jeu a ajouter</param>
        /// <param name="value">Valeur du noeud qui sera ajoute.</param>
        public void AddAt(int index, T value)
        {
            //On vérife si l'index est possible
            if (index >= 0 && index < nombre)
            {
                //On verifie si c'est le debut
                if (index == 0)
                    AjouterDebut(value);

                //On verifie si c'est la fin
                else if (index == nombre)
                    AjouterFin(value);

                //Sinon on parcour le tableau    
                else
                {
                    int curseur = 0;
                    Noeud<T> noeud;
                    //Si c'est avantageux par la fin
                    if (index >= nombre / 2 && index < nombre)
                    {
                        noeud = fin;
                        curseur = nombre - 1;
                        while (curseur > index)
                        {
                            noeud = noeud.Precedent;
                            curseur--;
                        }
                        Noeud<T> nouveauNoeud = new Noeud<T>(value);
                        nouveauNoeud.Precedent = noeud.Precedent;
                        nouveauNoeud.Suivant = noeud;
                        nouveauNoeud.Suivant.Precedent = nouveauNoeud;
                        nouveauNoeud.Precedent.Suivant = nouveauNoeud;
                        nombre++;

                    }
                    //Si c'est avantageux par le debut
                    else if (index < nombre / 2 && index >= 0)
                    {
                        noeud = debut;
                        curseur = 0;
                        while (curseur < index && curseur<nombre)
                        {
                            noeud = noeud.Suivant;
                            curseur++;
                        }
                        Noeud<T> nouveauNoeud = new Noeud<T>(value);
                        nouveauNoeud.Suivant = noeud;
                        nouveauNoeud.Precedent = noeud.Precedent;
                        nouveauNoeud.Suivant.Precedent = nouveauNoeud;
                        nouveauNoeud.Precedent.Suivant = nouveauNoeud;
                        nombre++;
                    }
                }
            }
            else
            {
                throw new InvalidOperationException();
            }

        }

        /// <summary>
        /// Ajoute une liste doublement chainee a l'index choisi.
        /// </summary>
        /// <param name="index">Index ou aura lieu l'ajout</param>
        /// <param name="data">Liste qui sera ajoute</param>
        public void AddAt(int index, ListeDoublementChainee<T> data)
        {
            //TODO : Verifier si on fait un add b4

            if(!data.EstVide)
            {
            //On vérife si l'index est possible
            if (index >= 0 && index < nombre)
            {
                //On verifie si c'est le debut
                if (index == 0)
                    AjouterDebut(data);

                //On verifie si c'est la fin
                else if (index == nombre - 1)
                    AjouterFin(data);

                //Sinon on parcour le tableau    
                else
                {
                    int curseurPos = 1;
                    Noeud<T> curseur;
                    ListeDoublementChainee<T> nouvelleListe = CopierListe(data);
                    //Si c'est avantageux par la fin
                    if (index >= nombre / 2 && index < nombre)
                    {
                        curseur = fin;
                        curseurPos = nombre - 1;
                        while (curseurPos > index || curseur.Precedent != null)
                        {
                            curseur = curseur.Precedent;
                            curseurPos--;
                        }
                        
                        nouvelleListe.Debut.Precedent = curseur;
                        nouvelleListe.Fin.Suivant = curseur.Suivant;
                        nouvelleListe.Fin.Suivant.Precedent = nouvelleListe.Fin;
                        nouvelleListe.Debut.Precedent.Suivant = nouvelleListe.Debut;

                    }
                    //Si c'est avantageux par le debut
                    else if (index < nombre / 2 && index >= 0)
                    {
                        curseur = debut;
                        curseurPos = 0;
                        while (curseurPos < index || curseur.Suivant != null)
                        {
                            curseur = curseur.Suivant;
                            curseurPos++;
                        }
                        nouvelleListe.Debut.Precedent = curseur;
                        nouvelleListe.Fin.Suivant = curseur.Suivant;
                        nouvelleListe.Fin.Suivant.Precedent = nouvelleListe.Fin;
                        nouvelleListe.Debut.Precedent.Suivant = nouvelleListe.Debut;
                    }
                    nombre += nouvelleListe.Nombre;
                }
            }            
            else
                    throw new InvalidOperationException("L'index se trouve en dehors des limites de la liste.");
        }
            else
                throw new InvalidOperationException("La liste que vous tentez d'ajouter est vide.");
        }



        /// <summary>
        /// Supprime et recupere le noeud du debut
        /// </summary>
        /// <returns>Noeud du supprime</returns>
        public T RetirerDebut()
        {
            if (!EstVide)
            {
                Noeud<T> noeudSupprime = debut;
                Noeud<T> noeud = debut.Suivant;
                if (noeud != null)
                {
                    noeud.Precedent = null;
                    debut.Suivant = null;
                    debut = noeud;
                    
                }
                nombre--;
                return noeudSupprime.Data;
            }
            else
                throw new InvalidOperationException("La liste est vide.");
        }

        /// <summary>
        /// Supprime et recupere le noeud du  fin
        /// </summary>
        /// <returns>Noeud du supprime</returns>
        public T RetirerFin()
        {
            if (!EstVide)
            {
                Noeud<T> noeudSupprime = fin;
                Noeud<T> noeud = fin.Precedent;
                if (noeud != null)
                {
                    noeud.Suivant = null;
                    fin.Precedent = null;
                    fin = noeud;
                    
                }
                nombre--;
                return noeudSupprime.Data;
            }
            else
                throw new InvalidOperationException("La liste est vide.");

        }

        /// <summary>
        /// Permet de retirer un element a l'index choisi.
        /// </summary>
        /// <param name="index">Index du noeud.</param>
        public T RetirerA(int index)
        {
            if (!EstVide)
            {
                //On vérife si l'index est possible
                if (index >= 0 && index < nombre)
                {
                    //On verifie si c'est le debut

                    if (index == 0)
                        return RetirerDebut();

                    //On verifie si c'est la fin
                    else if (index == nombre - 1)
                        return RetirerFin();

                    //Sinon on parcour le tableau    
                    else
                    {
                        int curseur = 0;
                        Noeud<T> noeud;
                        //Si c'est avantageux par la fin
                        if (index >= nombre / 2 && index < nombre)
                        {
                            noeud = fin;
                            curseur = nombre - 1;
                            while (curseur > index && curseur > 0)
                            {
                                noeud = noeud.Precedent;
                                curseur--;
                            }
                            noeud.Precedent.Suivant = noeud.Suivant;
                            noeud.Suivant.Precedent = noeud.Precedent;
                            nombre--;
                            return noeud.Data;

                        }
                        //Si c'est avantageux par le debut
                        else
                        {
                            noeud = debut;
                            curseur = 0;
                            while (curseur < index - 1 && curseur < nombre)
                            {
                                noeud = noeud.Suivant;
                                curseur++;
                            }
                            noeud.Precedent.Suivant = noeud.Suivant;
                            noeud.Suivant.Precedent = noeud.Precedent;
                            nombre--;
                            return noeud.Data;
                        }
                    }
                }
                else
                {
                    throw new InvalidOperationException("L'index est invalide.");
                }
            }
            else
                throw new InvalidOperationException("La liste est vide.");
        }

        /// <summary>
        /// Permet de lire un element a l'index choisi
        /// </summary>
        /// <param name="index">index dans la liste</param>
        public T ElementA(int index)
        {
            if (!EstVide)
            {
                Noeud<T> noeud = debut;
                if (index > nombre - 1 || index < 0)
                {
                    throw new InvalidOperationException();
                }
                for (int i = 0; i < index; i++)
                {
                    if (noeud != null)
                        noeud = noeud.Suivant;

                }
                return noeud.Data;
            }
            else
                throw new InvalidOperationException("Cette liste est vide.");

        }

        /// <summary>
        /// Permet de lire un noeud a l'index choisi
        /// </summary>
        /// <param name="index">index dans la liste</param>
        public Noeud<T> NoeudA(int index)
        {

            if (!EstVide)
            {
                Noeud<T> noeud = debut;
                if (index > nombre - 1 || index < 0)
                {
                    throw new InvalidOperationException();
                }
                for (int i = 0; i < index; i++)
                {
                    if (noeud != null)
                        noeud = noeud.Suivant;

                }
                return noeud;
            }
            else
                throw new InvalidOperationException("Cette liste est vide.");

        }

        

        /// <summary>
        /// Inverse la liste. On inverse le debut et la fin.
        /// </summary>
        public void Inverser()
        {
            if(!EstVide)
            {
                Noeud<T> curseur = debut;
                Noeud<T> noeudTemp;
                while(curseur != null)
                {
                    noeudTemp = curseur.Suivant;
                    curseur.Suivant = curseur.Precedent;
                    curseur.Precedent = noeudTemp;
                    curseur = curseur.Precedent; 

                }
                curseur = fin;
                fin = debut;
                debut = curseur;

            }
        }

        /// <summary>
        /// Copie une liste simplement chainee
        /// </summary>
        /// <param name="liste">Liste simplement chainee qui sera copie</param>
        /// <returns>Copie de la liste passe en parametre</returns>
        public ListeDoublementChainee<T> CopierListe(ListeDoublementChainee<T> liste)
        {
            if (!liste.EstVide)
            {
                ListeDoublementChainee<T> nouvelleListe = new ListeDoublementChainee<T>();
                Noeud<T> curseur = liste.Debut;
                while (curseur != null)
                {
                    nouvelleListe.AjouterFin(curseur.Data);
                    curseur = curseur.Suivant;
                }
                return nouvelleListe;
            }
            else
                throw new InvalidOperationException("La liste que vous souhaiter ajouter est vide.");
        }

        /// <summary>
        /// Permet de selectionner une partie d'une liste simplement chainée pour en retourner une sous-liste
        /// </summary>
        /// <param name="indexDebut">Index de debut de la selection.</param>
        /// <param name="indexFin">Index de la fin. Si celui-ci dépasse la taille de la liste, on prend le maximum.</param>
        /// <returns>Retourne une liste chainee selectionnee dans la liste parent</returns>
        public LinkedList<T> SousListe(int indexDebut, int indexFin)
        {
            LinkedList<T> sousListe = new LinkedList<T>();

            if (indexDebut >= 0 && indexDebut < indexFin && indexDebut < nombre)
            {
                int indexTemp = 0;
                Noeud<T> curseur = debut;
                while (indexTemp < indexDebut) //On trouve le debut
                {
                    curseur = curseur.Suivant;
                    indexTemp++;

                }
                while ((indexTemp <= indexFin && indexFin < nombre) || (indexTemp < nombre && indexFin > nombre))
                {
                    sousListe.AddLast(curseur.Data);
                    curseur = curseur.Suivant;
                    indexTemp++;
                }
            }
            else
                throw new InvalidOperationException("L'index entré est invalide");

            return sousListe;
        }

        /// <summary>
        /// Efface les noeuds de la liste.
        /// </summary>
        public void Vider()
        {
            debut = null;
            fin = null;
            nombre = 0;
        }

        //Proprietes

        /// <summary>
        /// Nombre de noeuds dans la chaine
        /// </summary>
        public int Nombre
        {
            get { return nombre; }
        }

        /// <summary>
        /// Noeud du debut de la liste.
        /// </summary>
        public Noeud<T> Debut
        {
            get { return debut; }
        }

        /// <summary>
        /// Retourne le data du premier noeud.
        /// </summary>
        public T PremierData
        {
            get { return debut.Data; }
        }

        /// <summary>
        /// Noeud de la fin de la liste
        /// </summary>
        public Noeud<T> Fin
        {
            get { return fin; }
            set { fin = value; }
        }

        /// <summary>
        /// Retourne le data du dernier noeud
        /// </summary>
        public T DernierData
        {
            get { return fin.Data; }
        }

        /// <summary>
        /// Retourne une valeur boolean. True si elle est vide et false si elle est pas vide.
        /// </summary>
        public bool EstVide
        {
            get
            {
                if (nombre == 0)
                    return true;
                else
                    return false;
            }

        }

        /// <summary>
        /// Retourne le tableau de cette liste chainee
        /// </summary>
        public T[] Tableau
        {
            get
            {
                int curseur = 0;
                T[] tableauNodes = new T[nombre];
                Noeud<T> noeud = debut;
                while (noeud != null)
                {
                    if (noeud.Data != null)
                        tableauNodes[curseur++] = noeud.Data;

                    noeud = noeud.Suivant;
                }
                return tableauNodes;
            }
        }

    }



}

