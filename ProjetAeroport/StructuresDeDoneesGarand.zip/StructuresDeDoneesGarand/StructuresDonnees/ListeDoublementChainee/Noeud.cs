﻿// Noeud.cs 
// Description du programme : 
// Programé par Alexis Coté
// Le : 21 octobre 2014         
// Historique des modifications
// Par :
// Le :
// Modif :

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Structure.ListeSimplementChainee
{
    public class Noeud<T>
    {
        //Variables membres

        private Noeud<T> suivant;
        private T data;


        //Constructeur

        /// <summary>
        /// Cree un noeud de type T
        /// </summary>
        /// <param name="data">Data qui sera assigne au noeud</param>
        public Noeud(T data)
        {
            this.data = data;
        }
        //Methodes

        //Proprietes

        /// <summary>
        /// Noeud Suivant
        /// </summary>
        public Noeud<T> Suivant
        {
            get { return suivant; }
            set { suivant = value; }
        }

        /// <summary>
        /// Valeur du noeud
        /// </summary>
        public T Data
        {
            get { return data; }
            set { data = value; }
        }
    }
}
