﻿// QueueOverFlowExpcetion.cs 
// Description du programme : Exception genere lorsqu'une queue est pleine.
// Programmé par Alexis Coté
// Le : 26 octobre 2014           
// Historique des modifications
// Par :
// Le :
// Modif :

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StructuresDonnees
{
    public class QueueOverFlowException : Exception
    {
        public QueueOverFlowException()
        {
        }

        public QueueOverFlowException(string message)
            : base(message)
        {
        }

        public QueueOverFlowException(string message, Exception inner)
            : base(message, inner)
        {
        }
    }
}
