﻿// Noeud.cs 
// Description du programme : Noeud de l'arbre binaire
// Programé par Alexis Coté
// Le : 16 septembre 2014            
// Historique des modifications
// Par : Alexis Côté
// Le : 26 octobre 2014
// Modif : J'ai modifier la propriete du data pour qu'il puisse seulement etre ajoute lors de sa creation.

using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Structure.Heap
{

    /// <summary>
    /// Permet d'aller chercher les donnés dans l'arbre.
    /// </summary>
    /// <param name="cle">Cle du noeud à aller chercher.</param>
    /// <returns>Retourne le Data du noeud avec la clé précisé. Le data est de type : T.</returns>
    /// <typeparam name="T">Type que contiendra le noeud </typeparam>
    public class Noeud<T> where T : IComparable<T>
    {
        //Variables membres

        Noeud<T> enfantGauche = null;
        Noeud<T> enfantDroit = null;
        T data;


        //Constructeur
        
        /// <summary>
        /// Cree un noeud et lui assigne sa donee.
        /// </summary>
        /// <param name="data">Donnee qui lui sera assigne.</param>
        public Noeud(T data)
        {
            this.data = data;
        }

        //Proprietes


        public Noeud<T> EnfantGauche
        {
            get { return enfantGauche; }
            set { enfantGauche = value; }
        }

        public Noeud<T> EnfantDroit
        {
            get { return enfantDroit; }
            set { enfantDroit = value; }
        }

        public T Data
        {
            get { return data; }
        }
    }
}