﻿// ListeSimplementChainee.cs 
// Description du programme : 
// Programé par Alexis Coté
// Le : 21 octobre 2014            
// Historique des modifications
// Par :
// Le :
// Modif :

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Structure.ListeSimplementChainee
{
    public class ListeSimplementChainee<T>
    {
        //Variables membres
        private int nombre;
        private Noeud<T> debut = null;
        private Noeud<T> fin = null;

    
        //Constructeur


        /// <summary>
        /// Cree une instance d'une liste chainee
        /// </summary>
        public ListeSimplementChainee()
        {
            nombre = 0;
        }

        /// <summary>
        /// Cree une instance de liste simplement chainee a partir d'une autre liste simplement chainee.s
        /// </summary>
        /// <param name="data">Liste Chainee du meme type que cette liste. Sera ajoute a la chaine.</param>
        public ListeSimplementChainee(ListeSimplementChainee<T> data)
        {
            this.AjouterDebut(data);
        }





        //Methodes

        /// <summary>
        /// Ajout d'un noeud au debut de la chaine
        /// </summary>
        /// <param name="valeur">Valeur attribue au noeud</param>
        public void AjouterDebut(T valeur)
        {
            Noeud<T> noeud = new Noeud<T>(valeur);
            if (debut == null)
            {
                fin = noeud;
            }
            else
                noeud.Suivant = debut;
            debut = noeud;
            nombre++;
        }

        /// <summary>
        /// Ajout d'un noeud au debut de la chaine
        /// </summary>
        /// <param name="valeur">Valeur attribue au noeud</param>
        public void AjouterDebut(ListeSimplementChainee<T> valeur)
        {
            if (!valeur.EstVide)
            {
                ListeSimplementChainee<T> nouvelleListe = CopierListe(valeur);
                if (debut != null) //Si la liste a un debut
                    nouvelleListe.Fin.Suivant = this.debut;
                else
                    fin = nouvelleListe.Fin;


                debut = nouvelleListe.Debut;
                nombre += nouvelleListe.nombre;
            }
            else
                throw new InvalidOperationException("La liste que vous voulez ajouter est vide.");
        }

        /// <summary>
        /// Ajout d'un noeud a la fin de la chaine
        /// </summary>
        /// <param name="valeur">Valeur attribue au noeud</param>
        public void AjouterFin(T valeur)
        {
            Noeud<T> noeud = new Noeud<T>(valeur);
            if (debut == null)
            {
                debut = noeud;
                fin = noeud;
            }
            else
            {
                Noeud<T> curseur = debut;
                while (curseur.Suivant != null)
                {
                    curseur = curseur.Suivant;
                }
                curseur.Suivant = noeud;
                fin = noeud;
            }
            nombre++;
        }

        /// <summary>
        /// Ajout d'un noeud a la fin de la chaine
        /// </summary>
        /// <param name="valeur">Valeur attribue au noeud</param>
        public void AjouterFin(ListeSimplementChainee<T> valeur)
        {
            if (!valeur.EstVide) //Si la liste en parametre n'est pas vide
            {
                ListeSimplementChainee<T> nouvelleListe = CopierListe(valeur);
                if (fin != null)
                    fin.Suivant = nouvelleListe.Debut;
                else
                    debut = nouvelleListe.Debut;
                fin = nouvelleListe.Fin;
                nombre += nouvelleListe.Nombre;
            }
            else
                throw new InvalidOperationException("La liste que vous comptez ajouter est vide.");
        }


        /// <summary>
        /// Retirer un noeud au debut de la chaine    
        /// </summary>
        public T RetirerDebut()
        {

            if (!EstVide)
            {
                Noeud<T> noeudSupprime = debut;
                if (debut == fin)
                {
                    fin = null;
                    debut = null;
                }
                else
                {
                    Noeud<T> noeud = debut.Suivant;
                    debut.Suivant = null;
                    debut = noeud;

                }
                nombre--;
                return noeudSupprime.Data;
            }
            else
                throw new InvalidOperationException("Il n'y a pas de noeuds");

        }

        /// <summary>
        /// Retire un noeud a la fin de la chaine
        /// </summary>
        public T RetirerFin()
        {
            if (!EstVide)
            {
                
                if (debut == fin)
                {
                    Noeud<T> noeudSupprime = debut;
                    debut = null;
                    fin = null;
                    nombre--;
                    return noeudSupprime.Data;
                }
                else
                {
                    Noeud<T> curseur = debut;
                    while (curseur.Suivant.Suivant != null)
                    {
                        curseur = curseur.Suivant;
                    }
                    Noeud<T> noeudSupprime = curseur.Suivant;
                    curseur.Suivant = null;
                    fin = curseur;
                    nombre--;
                    return noeudSupprime.Data;
                }
                
            }
            else
                throw new InvalidOperationException("Il n'y a aucun noeud");

        }

        /// <summary>
        /// Permet de lire un element a l'index choisi
        /// </summary>
        /// <param name="index">index dans la liste</param>
        public T ElementA(int index)
        {
            Noeud<T> noeud = debut;
            if (index > nombre - 1 || index < 0)
            {
                throw new InvalidOperationException();
            }
            for (int i = 0; i < index; i++)
            {
                if (noeud != null)
                    noeud = noeud.Suivant;

            }
            return noeud.Data;

        }

        /// <summary>
        /// Retourne le noeud a l'index demande
        /// </summary>
        /// <param name="index">Index du noeud a retrouver</param>
        /// <returns>Noeud recherche</returns>
        public Noeud<T> NoeudA(int index)
        {

            Noeud<T> noeud = debut;
            if (index > nombre - 1 || index < 0)
            {
                throw new InvalidOperationException();
            }
            for (int i = 0; i < index; i++)
            {
                if (noeud != null)
                    noeud = noeud.Suivant;

            }
            return noeud;


        }


        /// <summary>
        /// Permet de selectionner une partie d'une liste simplement chainée pour en retourner une sous-liste
        /// </summary>
        /// <param name="indexDebut">Index de debut de la selection.</param>
        /// <param name="indexFin">Index de la fin. Si celui-ci dépasse la taille de la liste, on prend le maximum.</param>
        /// <returns>Retourne une liste chainee selectionnee dans la liste parent</returns>
        public LinkedList<T> SousListe(int indexDebut, int indexFin)
        {
            LinkedList<T> sousListe = new LinkedList<T>();

            if (indexDebut >= 0 && indexDebut < indexFin && indexDebut < nombre)
            {
                int indexTemp = 0;
                Noeud<T> curseur = debut;
                while (indexTemp < indexDebut) //On trouve le debut
                {
                    curseur = curseur.Suivant;
                    indexTemp++;

                }
                while ((indexTemp <= indexFin && indexTemp<nombre) ||( indexTemp < nombre && indexFin>=nombre))
                {
                    sousListe.AddLast(curseur.Data);
                    curseur = curseur.Suivant;
                    indexTemp++;
                }
            }
            else
                throw new InvalidOperationException("L'index entré est invalide");

            return sousListe;
        }

        /// <summary>
        /// Permet d'ajouter un noeud a l'index choisi.
        /// </summary>
        /// <param name="index">Index qui precedera le nouveau jeu a ajouter</param>
        /// <param name="value">Valeur du noeud qui sera ajoute.</param>
        public void AjouterIndex(T value,int index)
        {
            //On vérife si l'index est possible
            if (index >= 0 && index < nombre)
            {
                //On verifie si c'est le debut
                if (index == 0)
                    AjouterDebut(value);

                else //Sinon on parcoure le tableau 
                {
                    int curseur = 0;
                    Noeud<T> noeud;

                    //Si c'est avantageux par le debut

                    noeud = debut;
                    curseur = 0;
                    while (curseur < index-1 && curseur < nombre)
                    {
                        noeud = noeud.Suivant;
                        curseur++;
                    }
                    Noeud<T> nouveauNoeud = new Noeud<T>(value);
                    nouveauNoeud.Suivant = noeud.Suivant;
                    noeud.Suivant = nouveauNoeud;
                    nombre++;

                }
            }
            else
            {
                throw new InvalidOperationException("L'index est invalide.");
            }

        }


        /// <summary>
        /// Permet d'ajouter une liste à l'index choisi.
        /// </summary>
        /// <param name="liste">Liste qui sera ajoute</param>
        /// <param name="index">Index a lequel la liste sera ajoute.</param>
        public void AjouterIndex(ListeSimplementChainee<T> liste,int index)
        {
            if (liste.Debut != null)
            {
                if (index >= 0 && index < nombre)
                {
                    if (index == 0)
                    {
                        this.AjouterDebut(liste);
                    }
                    else
                    {
                        Noeud<T> curseur = this.debut;
                        for (int i = 1; i < index - 1; i++) //On part à un parce que le curseur est déjà à 0 et on arrête un noeud avant l'index
                        {
                            curseur = curseur.Suivant;
                        }
                        //On garde en memoire le noeud suivant (Le noeud a l'index)
                        Noeud<T> suite = curseur.Suivant;
                        //Copie de liste
                        ListeSimplementChainee<T> nouvelleListe = CopierListe(liste);
                        curseur.Suivant = nouvelleListe.Debut;
                        nouvelleListe.Fin.Suivant = suite;
                        nombre += nouvelleListe.Nombre;
                    }


                }
                else
                    throw new InvalidOperationException("L'index se trouve en dehors des limites de la liste.");
            }
            else
                throw new InvalidOperationException("La liste que vous tentez d'ajouter est vide.");
        }


        /// <summary>
        /// Permet de retirer un noeud a une index donne
        /// </summary>
        /// <param name="index">Index ou se retrouve le noeud</param>
        /// <returns>Retourne le data que contenait le noeud</returns>
        public T SupprimerA(int index)
        {

            //On vérife si l'index est possible
            if (index >= 0 && index < nombre)
            {
                T dataSupprime;
                //On verifie si c'est le debut

                if (index == 0)
                    dataSupprime = RetirerDebut();

                //On verifie si c'est la fin
                else if (index == nombre - 1)
                    dataSupprime = RetirerFin();

                //Sinon on parcour le tableau    
                else
                {
                    int curseur = 0;
                    Noeud<T> noeud;

                    noeud = debut;
                    while (curseur < index - 1 && curseur < nombre)
                    {
                        noeud = noeud.Suivant;
                        curseur++;
                    }
                    Noeud<T> noeudSuivant = noeud.Suivant.Suivant;
                    dataSupprime = noeud.Suivant.Data;
                    noeud.Suivant.Suivant = null;
                    noeud.Suivant = noeudSuivant;
                    nombre--;
                }
                return dataSupprime;
            }
            else
            {
                throw new InvalidOperationException();
            }
        }

        /// <summary>
        /// Copie une liste simplement chainee
        /// </summary>
        /// <param name="liste">Liste simplement chainee qui sera copie</param>
        /// <returns>Copie de la liste passe en parametre</returns>
        private ListeSimplementChainee<T> CopierListe(ListeSimplementChainee<T> liste)
        {
            if (liste.Debut != null)
            {
                ListeSimplementChainee<T> nouvelleListe = new ListeSimplementChainee<T>();
                Noeud<T> curseur = liste.Debut;
                while (curseur != null)
                {
                    nouvelleListe.AjouterFin(curseur.Data);
                    curseur = curseur.Suivant;
                }
                return nouvelleListe;
            }
            throw new InvalidOperationException("La liste que vous tentez de copier est invalide.");
        }

        /// <summary>
        /// Efface les noeuds de la liste.
        /// </summary>
        public void Vider()
        {
            debut = null;
            fin = null;
            nombre = 0;
        }

        //Proprietes

        /// <summary>
        /// Nombre de noeuds dans la chaine
        /// </summary>
        public int Nombre
        {
            get { return nombre; }
        }

        /// <summary>
        /// Noeud du debut de la liste.
        /// </summary>
        public Noeud<T> Debut
        {
            get { return debut; }
        }

        /// <summary>
        /// Retourne le data du premier noeud.
        /// </summary>
        public T PremierData
        {
            get { return debut.Data; }
        }

        /// <summary>
        /// Noeud de la fin de la liste
        /// </summary>
        public Noeud<T> Fin
        {
            get { return fin; }
            set { fin = value; }
        }

        /// <summary>
        /// Retourne le data du dernier noeud
        /// </summary>
        public T DernierData
        {
            get { return fin.Data; }
        }

        /// <summary>
        /// Retourne une valeur boolean. True si elle est vide et false si elle est pas vide.
        /// </summary>
        public bool EstVide
        {
            get
            {
                if (nombre == 0)
                    return true;
                else
                    return false;
            }

        }
        
        /// <summary>
        /// Retourne le tableau de cette liste chainee
        /// </summary>
        public T[] Tableau
        {
            get
            {
                int curseur = 0;
                T[] tableauNodes = new T[nombre];
                Noeud<T> noeud = debut;
                while (noeud != null)
                {
                    if (noeud.Data != null)
                        tableauNodes[curseur++] = noeud.Data;

                    noeud = noeud.Suivant;
                }
                return tableauNodes;
            }
        }


    }
}
