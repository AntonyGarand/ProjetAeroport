﻿// Pile.cs 
// Description du programme : 
// Programé par Alexis Coté
// Le : 21 octobre 2014           
// Historique des modifications
// Par :
// Le :
// Modif :

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Structure.ListeSimplementChainee;

namespace Structure.Pile
{
    
    
    /// <summary>
    /// Struture de donnee d'une pile.Empile et depile des objets.
    /// </summary>
    public class Pile<T>:IStructureDeDonnee<T>
    {

        //Variables membres
        private int nombre;
        private Noeud<T> debut;
        private int tailleMax;

       
        

        //Constructeur

        /// <summary>
        /// Permet de creer une pile
        /// </summary>
        public Pile()
        {
            tailleMax = 1000000;
        }
        
        /// <summary>
        /// Permet de creer une pile.
        /// </summary>
        /// <param name="tailleMax">Sera la taille de la pile si possible</param>
        public Pile(int tailleMax)
        {
            if (tailleMax > 1000000)
                throw new StackOverflowException("La pile est trop grosse");
            else
                this.tailleMax = tailleMax;
        }

        /// <summary>
        /// Permet de creer une pile a l'aide d'une liste doublement chainee
        /// </summary>
        /// <param name="data">Liste qui sera ajoute a la pile.</param>
        public Pile(ListeSimplementChainee<T> data)
        {
            tailleMax = 1000000;
            if (data.Nombre <= 1000000)
            {
                T[] tableau = data.Tableau;
                for(int i=tableau.Length-1;i>=0;i--)
                {
                    this.Push(tableau[i]);
                }
            }
            else
                throw new StackOverflowException("La pile est trop grosse");
        }

        //Methodes

        /// <summary>
        /// Empile un objet dans la pile
        /// </summary>
        /// <param name="data">Objet de type T</param>
        public void Push(T data)
        {
            if (nombre < tailleMax)
            {
                Noeud<T> nouveauNoeud = new Noeud<T>(data);
                nouveauNoeud.Suivant = debut;
                debut = nouveauNoeud;
                nombre++;
            }
            else
                throw new StackOverflowException("La pile est trop grosse");
        }
        
        /// <summary>
        /// Retourne l'element au dessus de la pile et le supprime.
        /// </summary>
        /// <returns>L'element supprime.</returns>
        /// 
        public T Pop()
        {
            if (!EstVide)
            {
                T data = debut.Data;
                Noeud<T> noeudTemp = debut;
                debut = noeudTemp.Suivant;
                nombre--;
                return data;
            }
            throw new InvalidOperationException("Cette pile est vide.");
        }

        /// <summary>
        /// Retourne l'element au dessu de la pile;
        /// </summary>
        /// <returns></returns>
        public T Peek()
        {
            if (!EstVide)
                return debut.Data;
            else
                throw new InvalidOperationException("Cette pile est vide.");
        }

        /// <summary>
        /// Efface la pile au complet.
        /// </summary>
        public void Vider()
        {
            debut = null;
            nombre = 0;
        }

        //Proprietes


        /// <summary>
        /// Determine si la liste est vide ou pas.
        /// </summary>
        public bool EstVide
        {
            get
            {
                if (nombre == 0 || debut == null)
                    return true;
                return false;
                   
            }
        }

        /// <summary>
        /// Retourne la taille maximum de la pile.
        /// </summary>
        public int Taille
        {
            get { return tailleMax; }
        }
        /// <summary>
        /// Retourne en tableau la pile
        /// </summary>
        public T[] Tableau
        {
            get
            {
                int curseur = 0;
                T[] tableauNodes = new T[nombre];
                Noeud<T> noeud = debut;
                while (noeud.Suivant != null)
                {
                    if (noeud.Data != null)
                        tableauNodes[curseur] = noeud.Data;

                    noeud = noeud.Suivant;
                    curseur++;
                }
                return tableauNodes;
            }
        }
        
        public int Nombre
        {
            get { return nombre; }
        }

    }
    }

