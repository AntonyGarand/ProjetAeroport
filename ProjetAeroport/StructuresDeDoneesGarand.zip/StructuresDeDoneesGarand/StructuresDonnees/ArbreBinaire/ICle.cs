﻿// ICle.cs 
// Description du programme : Interface qui integre une cle pour tout objet.
// Programé par Alexis Coté
// Le : 19 septembre 2014            
// Historique des modifications
// Par :
// Le :
// Modif :

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Structure.ArbreBinaire
{
    public interface ICle
    {
         int Cle
        {
            get;
            set;
        }
    }
}
