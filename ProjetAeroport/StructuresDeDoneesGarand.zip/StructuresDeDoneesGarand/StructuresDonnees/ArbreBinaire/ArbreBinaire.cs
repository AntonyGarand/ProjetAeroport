﻿// ArbreBinaire.cs 
// Description du programme : En informatique, un arbre binaire est une structure de données qui peut se représenter sous
// la forme d'une hiérarchie dont chaque élément est appelé nœud, le nœud initial étant appelé racine. Dans un arbre binaire,
// chaque élément possède au plus deux éléments fils au niveau inférieur, habituellement appelés gauche et droit. Du point de 
// vue de ces éléments fils, l'élément dont ils sont issus au niveau supérieur est appelé père. Au niveau le plus élevé il y 
// a donc un nœud racine. Au niveau directement inférieur, il y a au plus deux nœuds fils. En continuant à descendre aux niveaux
// inférieurs, on peut en avoir quatre, puis huit, seize, etc. c'est-à-dire la suite des puissances de deux. Un nœud n'ayant aucun 
// fils est appelé feuille. Le nombre de niveaux total, autrement dit la distance entre la feuille la plus éloignée et la racine, 
// est appelé hauteur de l'arbre.Le niveau d'un nœud est appelé profondeur.
//
// Programé par Alexis Coté
// Le : 16 septembre 2014            
// Historique des modifications
// Par : Alexis cote
// Le : 26 octobre 2014
// Modif : Ajoute les nouveaux constructeurs et implementer l'interface IStructureDeDonnee

using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StructuresDonnees;
using Structure.ListeSimplementChainee;

namespace Structure.ArbreBinaire
{
    /// <summary>
    /// Classe de l'abre binaire. Lit et permet de gérer les noeuds ce cet arbre.
    /// </summary>
    /// <typeparam name="T">Type de contiendra l'arbre.</typeparam>
    public class ArbreBinaire<T>:IStructureDeDonnee<T> where T:IComparable<T>,ICle
    {
        //Variables membres

        private Noeud<T> racine = null;
        private int nombre;
        

        //Constructeur


        public ArbreBinaire()
        {
            nombre = 0;
        }



        //Methodes


        /// <summary>
        /// Permet d'aller chercher un element dans l'arbre. 
        /// </summary>
        /// <param name="cle"></param>
        /// <returns></returns>
        public T Trouver(int cle)
        {
            //On regarde si la racine est null ou pas.
            if (racine == null)
                throw new InvalidOperationException("Erreur, la clé n'existe pas");

            //On pointe notre curseur sur la racine.
            Noeud<T> curseur = racine;

            //Variable qui contiendra notre valeur de comparaison entre nos noeuds.
            int comparaison;

            while (true)
            {
                comparaison = curseur.Data.Cle.CompareTo(cle);
                if (comparaison == 0) //Curseur trouvé
                    return curseur.Data;
                else if (comparaison < 0) // Plus grand
                {

                    if (curseur.EnfantDroit == null)
                        throw new InvalidOperationException("Erreur, la clé n'existe pas");
                    //On avance le curseur
                    else
                    {
                        curseur = curseur.EnfantDroit;
                    }
                }
                else if (comparaison > 0) // Plus Petit
                {
                    if (curseur.EnfantGauche == null) // Enfant null
                        throw new InvalidOperationException("Erreur, la clé n'existe pas");
                    //On avance le curseur
                    else
                    {
                        curseur = curseur.EnfantGauche;
                    }
                }

            }
        }

        /// <summary>
        /// Classe l'arbre binaire en ordre.
        /// </summary>
        /// <returns>Liste Chainee avec les noeuds en ordre.</returns>
        public ListeSimplementChainee<T> EnOrdre()
        {
            if (!EstVide)
            {
                ListeSimplementChainee<T> liste = new ListeSimplementChainee<T>();
                EnOrdre(racine, ref liste);
                return liste;
            }
            else
                throw new InvalidOperationException("L'arbre est vide");
        }

        /// <summary>
        /// Classe l'arbre binaire en desordre.
        /// </summary>
        /// <returns>Liste Chainee avec les noeuds en desordre.</returns>
        public ListeSimplementChainee<T> Inverse()
        {
            if (!EstVide)
            {
                ListeSimplementChainee<T> liste = new ListeSimplementChainee<T>();
                EnDesordre(racine, ref liste);
                return liste;
            }
            else
                throw new InvalidOperationException("L'arbre est vide.");
        }

        /// <summary>
        /// Modifie la listechainee en parametre et ajoute les noeuds en ordre.
        /// </summary>
        /// <param name="localRoot">Noeud dont les enfants seront ajoute a la liste.</param>
        /// <param name="liste">Liste a laquelle sera ajoute les donnees des noeuds</param>
        private void EnOrdre(Noeud<T> localRoot,ref ListeSimplementChainee<T> liste)
        {
            if (localRoot != null)
            {
                EnOrdre(localRoot.EnfantGauche,ref liste);
                liste.AjouterFin(localRoot.Data);
                EnOrdre(localRoot.EnfantDroit,ref liste);
            }
        }


        /// <summary>
        /// Modifie la listechainee en parametre et ajoute les noeuds en desordre.
        /// </summary>
        /// <param name="localRoot">Noeud dont les enfants seront ajoute a la liste.</param>
        /// <param name="liste">Liste a laquelle sera ajoute les donnees des noeuds</param>
        private void EnDesordre(Noeud<T> localRoot, ref ListeSimplementChainee<T> liste)
        {
            if (localRoot != null)
            {
                EnDesordre(localRoot.EnfantDroit, ref liste);
                liste.AjouterFin(localRoot.Data);
                EnDesordre(localRoot.EnfantGauche, ref liste);
            }
        }

        /// <summary>
        /// Permet d'ajouter une noeud dans l'abre binaire. 
        /// </summary>
        /// <param name="noeud">Noeud de type generique. Il doit contenir un data.</param>
        public void Ajouter(T data)
        {
            Noeud<T> nouveauNoeud = new Noeud<T>(data);
            int resultat;
            if (racine == null) // Aucun noeud ajoute
            {
                racine = nouveauNoeud;
                nombre++;
            }
            else //S'il y a deja un noeud
            {
                //Noeud temporaire pour se deplacer dans l'abre
                Noeud<T> noeudTemp = racine;

                //On compare notre noeud avec la racine
                resultat = nouveauNoeud.Data.CompareTo(noeudTemp.Data);

                while ((resultat > 0 && noeudTemp.EnfantDroit != null) || (resultat < 0 && noeudTemp.EnfantGauche != null))
                {

                    if (resultat > 0) //Le noeud est plus grand
                    {
                        noeudTemp = noeudTemp.EnfantDroit;
                    }
                    else if (resultat < 0) //Le noeud est plus petit
                    {
                        noeudTemp = noeudTemp.EnfantGauche;
                    }
                    else if (resultat == 0) // Est égal
                    {
                        //On ne l'ajoute pas 
                        throw new InvalidOperationException("Le noeud suivant : " + nouveauNoeud.Data.Cle.ToString() + " existe déjà.");
                        //return;
                    }

                    //On compare notre noeud avec le curseur pour le prochain tour de loop
                    resultat = nouveauNoeud.Data.CompareTo(noeudTemp.Data);

                }
                if (resultat > 0) // Le noeud est plus grand
                {
                    noeudTemp.EnfantDroit = nouveauNoeud;
                    nombre++;
                }
                else if (resultat < 0) //Le noeud est plus petit
                {
                    noeudTemp.EnfantGauche = nouveauNoeud;
                    nombre++;
                }
                else if (resultat == 0) // Est égal
                {
                    //On ne l'ajoute pas 
                    throw new InvalidOperationException("Le noeud suivant : " + nouveauNoeud.Data.Cle.ToString() + " existe déjà.");
                }


            }
        }

        /// <summary>
        /// Supprime le noeud corespondat a la cle.
        /// </summary>
        /// <param name="cle">Cle du noeud a supprimer</param>
        /// <returns>True si le noeud est supprime. False s'il n'a pas ete supprime.</returns>
        public bool Supprimer(int cle)
        {
            if (racine == null)
                return false;
            //noeud
            Noeud<T> current = racine;
            Noeud<T> parent = racine;
            bool estEnfantGauche = true;

            while (current.Data.Cle != cle)
            {
                parent = current;
                //Comparer les clés
                if (cle < current.Data.Cle)
                {
                    current = current.EnfantGauche;
                    estEnfantGauche = true;
                }
                else
                {
                    current = current.EnfantDroit;
                    estEnfantGauche = false;
                }
                if (current == null)
                    return false;
            }//Fin while


            if (current.EnfantGauche == null && current.EnfantDroit == null) //Est enfant
            {
                if (current == racine)
                {
                    racine = null;
                    nombre--;
                    return true;
                }
                else if (estEnfantGauche)
                {
                    parent.EnfantGauche = null;
                    nombre--;
                    return true;
                }
                else
                {
                    parent.EnfantDroit = null;
                    nombre--;
                    return true;
                }
            }

            else if (current.EnfantGauche == null)
            {
                if (current == racine)
                {
                    racine = current.EnfantDroit;
                    nombre--;
                    return true;
                }

                if (estEnfantGauche)
                    parent.EnfantGauche = current.EnfantDroit;
                else
                    parent.EnfantDroit = current.EnfantDroit;

                nombre--;
                return true;

            }
            else if (current.EnfantDroit == null)
            {
                if (current == racine)
                {
                    racine = current.EnfantGauche;
                    nombre--;
                    return true;
                }

                if (estEnfantGauche)
                    parent.EnfantGauche = current.EnfantGauche;
                else
                    parent.EnfantDroit = current.EnfantGauche;
                nombre--;
                return true;
            }

            Noeud<T> successeur = DetacherSuccesseur(current);
            if (current == racine)
            {
                successeur.EnfantGauche = parent.EnfantGauche;
                successeur.EnfantDroit = parent.EnfantDroit;
                racine = successeur;
                nombre--;
                return true;
            }
            else
            {
                // Faire lien
                if (estEnfantGauche)
                {
                    successeur.EnfantGauche = parent.EnfantGauche.EnfantGauche;
                    successeur.EnfantDroit = parent.EnfantGauche.EnfantDroit;
                    parent.EnfantGauche = successeur;
                }
                else
                {
                    successeur.EnfantGauche = parent.EnfantDroit.EnfantGauche;
                    successeur.EnfantDroit = parent.EnfantDroit.EnfantDroit;
                    parent.EnfantDroit = successeur;
                }
                nombre--;
                return true;
            }




        }

        /// <summary>
        /// Detache le successeur du noeud.
        /// </summary>
        /// <param name="delNode">Noeud auquel on trouvera le successeur</param>
        /// <returns>Le successeur.</returns>
        private Noeud<T> DetacherSuccesseur(Noeud<T> delNode)
        {
            Noeud<T> parentSucc = delNode;
            Noeud<T> succ = delNode;
            Noeud<T> current = delNode.EnfantDroit;

            while (current != null)
            {
                parentSucc = succ;
                succ = current;
                current = current.EnfantGauche;
            }
            if (succ != delNode.EnfantDroit)
            {
                parentSucc.EnfantGauche = succ.EnfantDroit;
            }
            else
                parentSucc.EnfantDroit = succ.EnfantDroit;
            succ.EnfantGauche = null;
            succ.EnfantDroit = null;
            return succ;

        }

        /// <summary>
        /// Retourne l'element racine de cet arbre.
        /// </summary>
        /// <returns>Donee de la racine de cet arbre.</returns>
        public T Peek()
        {
            if (!EstVide)
                return racine.Data;
            else
                throw new InvalidOperationException("L'arbre est vide!");
        }

        /// <summary>
        /// Permet de vider completement un arbre binaire.
        /// </summary>
        public void Vider()
        {
            racine = null;
            nombre = 0;
            //TODO: Optimiser.
        }

        //Proprietes

        

        /// <summary>
        /// Retourne le nombre de donnee dans l'arbre.
        /// </summary>
        public int Nombre
        {
            get { return nombre; }
        }

        /// <summary>
        /// Determine si l'arbre est vide.
        /// </summary>
        public bool EstVide
        {
            get {
                if (racine == null)
                    return true;
                return false;
            }
        }

        /// <summary>
        /// Retourne l'arbre sous le format d'un tableau.
        /// </summary>
        public T[] Tableau
        {
            get
            {
                ListeSimplementChainee<T> liste = EnOrdre();
                return liste.Tableau;
            }
        }

        /// <summary>
        /// Taille de l'arbre
        /// </summary>
        public int Taille
        {
            get { return nombre; }
        }

    }


   
}



