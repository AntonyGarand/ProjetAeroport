﻿// CleTest.cs 
// Description du programme :  Classe personnalise pour tester les arbres binaires
// Programé par Alexis Coté
// Le : 25 aout 2014            
// Historique des modifications
// Par : 
// Le :
// Modif :

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Structure.ArbreBinaire
{
    public class CleTest:IComparable<CleTest>,ICle
    {
        //Variables membres
        private int cle;

        //Constructeur

        public CleTest(int cle)
        {
            this.cle = cle;
        }

        //Methodes

        
        

        //Proprietes





         public int Cle
         {
             get
             {
                 return this.cle;
             }
             set
             {
                 this.cle = value;
             }
         }


         /// <summary>
         /// Compare 2 objets avec l'interface ICle
         /// </summary>
         /// <param name="obj">Objet de type ICle</param>
         /// <returns>Retourne un chiffre inférieur à 0 si l'objet est plus petit que celui comparé. 0 s'ils sont égaux. Supérieur à 1 si l'objet est plus grand que celui compare.</returns>
         public int CompareTo(CleTest other)
         {
             return this.cle - other.Cle;
         }
    }
}
