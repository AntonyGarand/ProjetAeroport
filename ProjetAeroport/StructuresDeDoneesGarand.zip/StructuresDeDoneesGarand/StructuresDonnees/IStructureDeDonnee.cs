﻿// IStructureDeDonnee.cs 
// Description du programme : Implemente les methodes et variables de base pour les structures de données
// Programé par Alexis Coté
// Le : 21 octobre 2014            
// Historique des modifications
// Par :
// Le :
// Modif :

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Structure
{
    interface IStructureDeDonnee<T>
    {
        T Peek();
        void Vider();

        int Nombre{get;}
        bool EstVide{ get; }
        T[] Tableau { get; }
    }
}
