﻿// File.cs 
// Description du programme : 
// Programmé par Alexis Coté
// Le : 26 octobre 2014            
// Historique des modifications
// Par :
// Le :
// Modif :

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Structure.ListeSimplementChainee;
using StructuresDonnees;

namespace Structure.File
{
    /// <summary>
    /// Structure de donnee de type File. Agit comme une file de donnée avec une debut et une fin.
    /// </summary>
    public class File<T> : IStructureDeDonnee<T>
    {
        //Variables membres
        private int nombre;
        private int taille;
        private Noeud<T> tete;
        private Noeud<T> queue;

        //Constructeur

        /// <summary>
        /// Cree une file avec une taille de 1000000.
        /// </summary>
        public File()
        {
            taille = 1000000;
        }
        
        /// <summary>
        /// Cree une file avec une taille definie.
        /// </summary>
        /// <param name="taille">Taille de la file.</param>
        public File(int taille)
        {
            if (taille > 1000000)
                throw new QueueOverFlowException("La queue est pleine!");
            else
                this.taille = taille;
        }

        /// <summary>
        /// Cree une file a partir d'une liste chainee.
        /// </summary>
        /// <param name="data">Liste chainee qui sera ajoute a la file.</param>
        public File(ListeSimplementChainee<T> data)
        {
            if (data.Debut != null)
            {
                taille = 1000000;
                Noeud<T> curseur = data.Debut;
                while(curseur.Suivant != null)
                {
                    this.Enqueue(curseur.Data);
                    curseur = curseur.Suivant;
                }
            }
            else
                throw new InvalidOperationException("La liste chainee est vide!");
        }
        //Methodes

        /// <summary>
        /// Ajoute une noeud a la fin de la file
        /// </summary>
        /// <param name="data">Donnee du nouveau noeud.</param>
        public void Enqueue(T data)
        {
            Noeud<T> nouveauNoeud = new Noeud<T>(data);
            if(EstVide)
            {
                tete = nouveauNoeud;
            }
            else
            {
                if (nombre < taille)
                    queue.Suivant = nouveauNoeud;
                else
                    throw new QueueOverFlowException("La file est pleine.");
            }  
            queue = nouveauNoeud;
            nombre++;
        }

        /// <summary>
        /// Retourne la tete de la file.
        /// </summary>
        /// <returns>Data de la tete</returns>
        public T Peek()
        {
            if (!EstVide)
                return tete.Data;
            else
                throw new InvalidOperationException("La file est vide!");
        }

        /// <summary>
        /// Supprime le noeud en tete et retourne sa valeur
        /// </summary>
        /// <returns>La valeur du noeud supprime.</returns>
        public T Dequeue()
        {
            if (!EstVide)
            {
                Noeud<T> noeudSuppr = tete;
                if(tete == queue) // Seulement 1 noeud
                {
                    tete = null;
                    queue = null;
                    nombre--;
                    return noeudSuppr.Data;
                }
                else
                {
                    tete = tete.Suivant;
                    noeudSuppr.Suivant = null;
                    nombre--;
                    return noeudSuppr.Data;
                }
            }
            else
                throw new InvalidOperationException("La file est vide.");
        }

        /// <summary>
        /// Vide la file de tout ses noeuds.
        /// </summary>
        public void Vider()
        {
            if (!EstVide)
            {
                tete = null;
                queue = null;
                nombre = 0;
            }
        }


        //Proprietes

        /// <summary>
        /// Retourne le nombre d'elements dans cette file.
        /// </summary>
        public int Nombre
        {
            get { return nombre; }
        }

        /// <summary>
        /// Retourne la taille maximale de la file.
        /// </summary>
        public int Taille
        {
            get { return taille; }
        }

        /// <summary>
        /// Determine si la file est pleine ou vide.
        /// </summary>
        public bool EstVide
        {
            get
            {
                if (nombre == 0)
                    return true;
                return false;
            }
        }

        /// <summary>
        /// Retourne le tableau de cette file.
        /// </summary>
        public T[] Tableau
        {
            get
            {
                int curseur = 0;
                T[] tableauNodes = new T[nombre];
                Noeud<T> noeud = tete;
                while (noeud.Suivant != null)
                {
                    if (noeud.Data != null)
                        tableauNodes[curseur] = noeud.Data;

                    noeud = noeud.Suivant;
                    curseur++;
                }
                return tableauNodes;
            }
        }
    }
}
